"use client"
import React, { useState } from "react";
import { format, addMonths, subMonths } from "date-fns";
import { fr } from "date-fns/locale";

export default function VotreSalarie2({
  data,
  setData,
  onNext,
  onPrev,
  isLastStep,
  isCurrentStepComplete,
}) {
  const [selectedDate, setSelectedDate] = useState(null);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [selectedTime, setSelectedTime] = useState("16:03");

  const months = [
    "Janvier", "Février", "Mars", "Avril", "Mai", "Juin", 
    "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"
  ];

  const daysOfWeek = ["L", "M", "Me", "J", "V", "S", "D"];

  const getDaysInMonth = (date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const renderCalendar = () => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    const daysInMonth = getDaysInMonth(currentMonth);
    const firstDay = getFirstDayOfMonth(currentMonth);

    let days = [];
    for (let i = 0; i < firstDay === 0 ? 6 : firstDay - 1; i++) {
      days.push(<div key={`empty-${i}`} className=""></div>);
    }

    for (let day = 1; day <= daysInMonth; day++) {
      const currentDate = new Date(year, month, day);
      const isSelected = selectedDate && 
        currentDate.toDateString() === selectedDate.toDateString();

      days.push(
        <div
          key={day}
          onClick={() => handleDateSelect(currentDate)}
          className={`text-center cursor-pointer p-1 hover:bg-red-200 
            ${isSelected ? 'bg-red-500 text-white' : 'hover:bg-red-100'}`}
        >
          {day}
        </div>
      );
    }

    return days;
  };

  const handleDateSelect = (date) => {
    setSelectedDate(date);
    setIsCalendarOpen(false);
    setData({
      ...data,
      startDate: format(date, "dd/MM/yyyy"),
    });
  };

  const handleTimeChange = (e) => {
    setSelectedTime(e.target.value);
    setData({
      ...data,
      startTime: e.target.value,
    });
  };

  const handlePrevMonth = () => {
    setCurrentMonth(subMonths(currentMonth, 1));
  };

  const handleNextMonth = () => {
    setCurrentMonth(addMonths(currentMonth, 1));
  };

  return (
    <div className="mt-10 pl-4 max-w-2xl bg-[#FCFCFC]">
      <div className="flex flex-col bg-[#FCFCFC]">
        <div className="w-full max-w-[500px] text-left">
          <div className="flex flex-wrap items-baseline gap-2 pb-5">
            <div className="text-teal-950 text-4xl font-semibold">
              La rémunération
            </div>
            <div className="text-[#99C2E1] text-2xl">
              / Votre bulletin de paie
            </div>
          </div>
        </div>
      </div>

      <div className="text-base" style={{ color: "#0A2C2D" }}>
        <div className="flex flex-wrap items-center gap-2 mb-4">
          <span>Mon salarié a débuté le</span>

          {/* Date Picker */}
          <div className="relative">
            <input
              type="text"
              value={selectedDate ? format(selectedDate, "dd/MM/yyyy") : ""}
              onClick={() => setIsCalendarOpen(!isCalendarOpen)}
              readOnly
              className="border rounded px-2 py-1 cursor-pointer"
              placeholder="Date"
            />
            {isCalendarOpen && (
              <div className="absolute z-10 w-64 bg-white border rounded-lg shadow-lg overflow-hidden">
                <div className="bg-red-500 text-white flex justify-between items-center p-2">
                  <button 
                    onClick={handlePrevMonth} 
                    className="text-white hover:bg-red-600 rounded-full p-1"
                  >
                    &lt;
                  </button>
                  <span className="font-bold">
                    {months[currentMonth.getMonth()]} {currentMonth.getFullYear()}
                  </span>
                  <button 
                    onClick={handleNextMonth} 
                    className="text-white hover:bg-red-600 rounded-full p-1"
                  >
                    &gt;
                  </button>
                </div>
                <div className="grid grid-cols-7 gap-1 text-center p-2">
                  {daysOfWeek.map((day, index) => (
                    <div key={`${day}-${index}`} className="font-bold text-sm">
                      {day}
                    </div>
                  ))}
                  {renderCalendar()}
                </div>
              </div>
            )}
          </div>

          {/* Time Picker */}
          <input
            type="text"
            value={selectedTime}
            onChange={handleTimeChange}
            className="border rounded px-2 py-1 w-16"
            placeholder="Heure"
          />
        </div>
      </div>

      {/* Navigation buttons */}
      <div className="mt-8 flex gap-4">
        <button
          onClick={onPrev}
          className="flex items-center gap-2 px-8 py-3 rounded-md bg-[#D5F5F6] text-gray-700 hover:bg-blue-100 transition-colors duration-200 shadow-sm hover:shadow-md"
        >
          ← Précédent
        </button>
        <button
          onClick={onNext}
          disabled={!isCurrentStepComplete}
          className={`flex items-center gap-2 px-8 py-3 rounded-md transition-colors duration-200 shadow-md hover:shadow-lg 
            ${
              isCurrentStepComplete
                ? "bg-[#E42724] text-white hover:bg-red-700"
                : "bg-gray-400 text-gray-200 cursor-not-allowed"
            }`}
        >
          {isLastStep ? "Terminer" : "Suivant"} →
        </button>
      </div>
    </div>
  );
}