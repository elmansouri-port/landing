import React, { useState } from "react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export default function VotreSalarie2({
  data,
  setData,
  onNext,
  onPrev,
  isLastStep,
  isCurrentStepComplete,
}) {
  const [selectedDate, setSelectedDate] = useState(null);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [selectedTime, setSelectedTime] = useState("16:03");
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const months = [
    "Janvier",
    "Février",
    "Mars",
    "Avril",
    "Mai",
    "Juin",
    "Juillet",
    "Août",
    "Septembre",
    "Octobre",
    "Novembre",
    "Décembre",
  ];

  const daysOfWeek = ["L", "M", "M", "J", "V", "S", "D"];

  const getDaysInMonth = (year, month) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (year, month) => {
    return new Date(year, month, 1).getDay();
  };

  const renderCalendar = () => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    const daysInMonth = getDaysInMonth(year, month);
    const firstDay = getFirstDayOfMonth(year, month);

    let days = [];
    // Empty days at start
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="h-8"></div>);
    }

    // Actual days
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(year, month, day);
      const isSelected =
        selectedDate &&
        format(selectedDate, "yyyy-MM-dd") === format(date, "yyyy-MM-dd");

      days.push(
        <div
          key={day}
          onClick={() => handleDateSelect(date)}
          className={`h-8 flex items-center justify-center cursor-pointer rounded-full
            ${isSelected ? "bg-red-500 text-white" : "hover:bg-red-100"}`}
        >
          {day}
        </div>
      );
    }

    // Fill remaining empty days
    const totalCells = days.length;
    const remainingCells = 42 - totalCells; // 6 rows x 7 days
    for (let i = 0; i < remainingCells; i++) {
      days.push(<div key={`empty-end-${i}`} className="h-8"></div>);
    }

    return days;
  };

  const handleDateSelect = (date) => {
    setSelectedDate(date);
    setIsCalendarOpen(false);
    setData({
      ...data,
      startDate: format(date, "dd/MM/yyyy"),
    });
  };

  const handleTimeChange = (e) => {
    setSelectedTime(e.target.value);
    setData({
      ...data,
      startTime: e.target.value,
    });
  };

  return (
    <div className="mt-10 pl-4 max-w-2xl bg-[#FCFCFC]">
      <div className="flex flex-col bg-[#FCFCFC]">
        <div className="w-full max-w-[500px] text-left">
          <div className="flex flex-wrap items-baseline gap-2 pb-5">
            <div className="text-teal-950 text-4xl font-semibold">
              La rémunération
            </div>
            <div className="text-[#99C2E1] text-2xl">
              / Votre bulletin de paie
            </div>
          </div>
        </div>
      </div>

      <div className="text-base" style={{ color: "#0A2C2D" }}>
        <div className="flex flex-wrap items-center gap-2 mb-4">
          <span>Mon salarié a débuté le</span>

          {/* Date Picker */}
          <div className="relative">
            <input
              type="text"
              value={selectedDate ? format(selectedDate, "dd/MM/yyyy") : ""}
              onClick={() => setIsCalendarOpen(!isCalendarOpen)}
              readOnly
              className="border rounded px-2 py-1 cursor-pointer"
              placeholder="Date"
            />
            {isCalendarOpen && (
              <div className="absolute z-10 w-85 bg-white border rounded-lg shadow-lg overflow-hidden mt-1">
                <div className="flex justify-center items-center bg-red-500 text-white p-2">
                  <div className="w-9 h-9 p-2 flex items-center justify-center">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setCurrentMonth(
                          new Date(
                            currentMonth.getFullYear(),
                            currentMonth.getMonth() - 1,
                            1
                          )
                        );
                      }}
                      className="text-white hover:bg-red-600 rounded-full p-1"
                    >
                      <svg
                        width="17"
                        height="16"
                        viewBox="0 0 17 16"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M10.5 12L6.5 8L10.5 4"
                          stroke="white"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                    </button>
                  </div>
                  <div className="text-center mx-4">
                    {months[currentMonth.getMonth()]}{" "}
                    {currentMonth.getFullYear()}
                  </div>
                  <div className="w-9 h-9 p-2 flex items-center justify-center">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setCurrentMonth(
                          new Date(
                            currentMonth.getFullYear(),
                            currentMonth.getMonth() + 1,
                            1
                          )
                        );
                      }}
                      className="text-white hover:bg-red-600 rounded-full p-1"
                    >
                      <svg
                        width="17"
                        height="16"
                        viewBox="0 0 17 16"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M6.5 4L10.5 8L6.5 12"
                          stroke="white"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-7 gap-1 text-center p-5">
                  {daysOfWeek.map((day, index) => (
                    <div
                      key={`day-${index}`}
                      className="font-bold text-sm py-1 text-[#0A2C2D99]"
                    >
                      {day}
                    </div>
                  ))}
                  {renderCalendar()}
                </div>
              </div>
            )}
          </div>

          {/* Time Picker */}
          <input
            type="text"
            value={selectedTime}
            onChange={handleTimeChange}
            className="border rounded px-2 py-1 w-16"
            placeholder="Heure"
          />
        </div>
      </div>

      {/* Navigation buttons */}
      <div className="mt-8 flex gap-4">
        <button
          onClick={onPrev}
          className="flex items-center gap-2 px-8 py-3 rounded-md bg-[#D5F5F6] text-gray-700 hover:bg-blue-100 transition-colors duration-200 shadow-sm hover:shadow-md"
        >
          ← Précédent
        </button>
        <button
          onClick={onNext}
          disabled={!isCurrentStepComplete}
          className={`flex items-center gap-2 px-8 py-3 rounded-md transition-colors duration-200 shadow-md hover:shadow-lg 
            ${
              isCurrentStepComplete
                ? "bg-[#E42724] text-white hover:bg-red-700"
                : "bg-gray-400 text-gray-200 cursor-not-allowed"
            }`}
        >
          {isLastStep ? "Terminer" : "Suivant"} →
        </button>
      </div>
    </div>
  );
}
