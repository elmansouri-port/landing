export default function Email({ data, setData }) {
  return (
    <div>
      <h2>Email</h2>
      <p>Placeholder for Email content.</p>
    </div>
  );
}