export default function VotreEstimation({ data, setData }) {
  return (
    <div>
      <h2>Votre Estimation</h2>
      <p>Placeholder for Votre Estimation content.</p>
    </div>
  );
}